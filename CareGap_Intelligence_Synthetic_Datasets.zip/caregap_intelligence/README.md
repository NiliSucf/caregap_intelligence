# CareGap Intelligence — Step 1 Synthetic Dataset

## Purpose
These CSV files are synthetic training data for a portfolio project using Snowflake SQL and Power BI. They do not describe real people and must not be used for clinical decisions.

## Files
- PATIENTS.csv: one intended row per synthetic patient
- ENCOUNTERS.csv: synthetic encounters from the 18 months before the as-of date
- SCREENINGS.csv: synthetic screening history covering up to five years, to allow interval logic to be tested
- SCREENING_RULES.csv: simplified, illustrative training rules
- CLINICS.csv: five fictional clinics

## Project as-of date
2026-10-01. Use this fixed date for reproducible calculations rather than CURRENT_DATE().

## Important clinical-safety limitation
The age ranges and intervals in SCREENING_RULES.csv are invented/simplified training assumptions, NOT official screening recommendations or clinical guidance. In particular, the interval for colorectal screening is deliberately simplified for SQL practice. A real clinical implementation would require current authoritative guidelines, measure-specific logic, exclusions, clinician review, and validation.

## Intentional data-quality cases
A small number of rows contain missing values, and SCREENINGS.csv contains a duplicated row/ID. These are deliberate so the project can demonstrate data-quality checks and cleanup. Do not silently remove them: identify and document them in SQL first.

## Data modeling notes
- PATIENTS.patient_id links to ENCOUNTERS.patient_id and SCREENINGS.patient_id.
- PATIENTS.clinic_id and ENCOUNTERS.clinic_id link to CLINICS.clinic_id.
- SCREENINGS has one row per recorded screening event in the intended model, but one deliberate duplicate exists for validation practice.
- SCREENING_RULES has one row per screening category.
- Breast screening eligibility in this synthetic exercise will additionally be limited to records where sex = Female. This is an explicit project assumption for practicing rules, not a substitute for real-world clinical eligibility logic.

## Suggested next step
Create a database named CAREGAP_DB and schema named RAW, then load these CSVs into matching raw tables using Snowsight.
